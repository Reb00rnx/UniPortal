package com.uniportal.Controller;


import com.uniportal.User.Dto.StudentRequestDto;
import com.uniportal.User.Dto.StudentResponseDto;
import com.uniportal.User.Dto.TeacherRequestDto;
import com.uniportal.User.Dto.TeacherResponseDto;
import com.uniportal.Service.UserService;
import com.uniportal.User.User;
import jakarta.validation.Valid;
import org.apache.coyote.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }


    @DeleteMapping("/students/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id){
        userService.deleteStudent(id);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/teachers/{id}")
    public ResponseEntity<Void> deleteTeacher(@PathVariable Long id){
        userService.deleteTeacher(id);

        return ResponseEntity.noContent().build();
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<Object> getUserInfo(@PathVariable Long  id){
        Object response = userService.getUser(id);
        return ResponseEntity.ok().body(response);
    }






}
